RememberPills iOS App — v2

This is the corrected iOS project. The app starts at the actual RememberPills user
DASHBOARD, not the public RememberPills.com homepage.

DASHBOARD URL
https://www.rememberpills.com/dashboard.php

LOGIN BEHAVIOR
- WKWebView uses Apple's persistent website data store.
- Existing RememberPills login cookies/session data can persist between app launches.
- If the user is already authenticated, tapping the app icon takes them directly to
  dashboard.php.
- If the session has expired, the website can show its normal login page. After login,
  the site returns the user to the dashboard.

OTHER FIXES
- RememberPills target=_blank/window.open links stay in the app.
- Non-RememberPills web destinations open in Safari.
- Native iOS share sheet is used instead of ShareLink, preserving iOS 13 support.
- No refreshable/ShareLink APIs that require newer iOS versions are used.

APP IDENTIFIERS
Bundle ID: com.rememberpills.app
Display Name: RememberPills
Version: 1.0
Build: 2
Deployment target: iOS 13.0

BUILD / DISTRIBUTION
A Mac with Xcode 26 or later and an Apple Developer account are required to sign,
archive, validate, and upload the app to App Store Connect under Apple's current
submission requirements.

Before App Store submission, provide App Review with a working test account if the
RememberPills dashboard requires authentication.
