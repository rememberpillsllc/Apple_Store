import SwiftUI
import WebKit
import Network
import UIKit

private let rememberPillsDashboardURL = URL(string: "https://www.rememberpills.com/dashboard.php")!
private let rememberPillsHost = "www.rememberpills.com"
private let rememberPillsHostNoWWW = "rememberpills.com"

struct ContentView: View {
    @StateObject private var model = WebViewModel()
    @State private var showingShareSheet = false

    var body: some View {
        VStack(spacing: 0) {
            if !model.isOnline {
                Text("No internet connection. RememberPills.com will reconnect automatically.")
                    .font(.footnote)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 7)
                    .background(Color.orange.opacity(0.18))
            }

            WebContainer(webView: model.webView)

            Divider()

            HStack(spacing: 0) {
                Button { model.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!model.canGoBack)
                Spacer()
                Button { model.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!model.canGoForward)
                Spacer()
                Button { model.openDashboard() } label: { Image(systemName: "house") }
                    .accessibilityLabel("Open dashboard")
                Spacer()
                Button { model.reload() } label: { Image(systemName: "arrow.clockwise") }
                    .accessibilityLabel("Refresh dashboard")
                Spacer()
                Button { showingShareSheet = true } label: { Image(systemName: "square.and.arrow.up") }
                    .accessibilityLabel("Share")
            }
            .font(.system(size: 18, weight: .semibold))
            .padding(.horizontal, 24)
            .padding(.vertical, 11)
            .background(.ultraThinMaterial)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .onAppear { model.start() }
        .sheet(isPresented: $showingShareSheet) {
            ActivityView(activityItems: [model.shareURL])
        }
    }
}

final class WebViewModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isOnline = true

    let webView: WKWebView
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "RememberPills.Network")
    private var started = false

    var shareURL: URL { webView.url ?? rememberPillsDashboardURL }

    override init() {
        let config = WKWebViewConfiguration()
        // Persistent cookies/session data let an authenticated user return directly
        // to the dashboard when the app icon is tapped again.
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.alwaysBounceVertical = true
        webView.allowsLinkPreview = false
    }

    func start() {
        guard !started else { return }
        started = true
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async { self?.isOnline = path.status == .satisfied }
        }
        monitor.start(queue: queue)

        // Never start at the public homepage. Always start at the user dashboard.
        openDashboard()
    }

    func openDashboard() {
        webView.load(URLRequest(url: rememberPillsDashboardURL,
                                cachePolicy: .useProtocolCachePolicy,
                                timeoutInterval: 30))
    }

    func reload() { webView.reload() }
    func goBack() { if webView.canGoBack { webView.goBack() } }
    func goForward() { if webView.canGoForward { webView.goForward() } }

    private func updateNavigationState() {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        updateNavigationState()
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        updateNavigationState()
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }

        // Handle target="_blank" RememberPills links inside the app.
        if navigationAction.targetFrame == nil,
           (url.scheme == "http" || url.scheme == "https"),
           isRememberPillsURL(url) {
            webView.load(URLRequest(url: url))
            decisionHandler(.cancel)
            return
        }

        if url.scheme == "http" || url.scheme == "https" {
            if isRememberPillsURL(url) {
                decisionHandler(.allow)
            } else {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
            }
        } else {
            decisionHandler(.allow)
        }
    }

    private func isRememberPillsURL(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return host == rememberPillsHost || host == rememberPillsHostNoWWW
    }

    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else { return nil }
        if isRememberPillsURL(url) {
            webView.load(URLRequest(url: url))
        } else {
            UIApplication.shared.open(url)
        }
        return nil
    }
}

struct WebContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
