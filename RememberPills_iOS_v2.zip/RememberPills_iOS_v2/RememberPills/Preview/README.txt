RememberPills iOS project preview assets.
