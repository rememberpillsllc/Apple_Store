RememberPills iOS v1

Architecture:
- Native SwiftUI shell
- WKWebView for RememberPills.com
- Native navigation controls: back, forward, refresh, Share, Safari
- Network status banner
- Pull-to-refresh support
- External websites open in Safari

Bundle ID: com.rememberpills.app
Minimum iOS deployment target: iOS 13.0
Build requirement for App Store Connect as of 2026-10-02: Xcode 26+ with iOS 26 SDK or later.

IMPORTANT:
This project is source code, not a signed IPA. It must be built and signed on a Mac with Xcode and an Apple Developer account.

Before App Store submission:
1. Open RememberPills.xcodeproj in Xcode.
2. Select your Apple Developer Team under Signing & Capabilities.
3. Confirm the Bundle Identifier is available/registered.
4. Build and test on an iPhone/iPad.
5. Create the App Store Connect record and upload through Xcode/Transporter.
6. Complete privacy, age rating, support URL, privacy policy URL, screenshots, and review notes.
7. Because Apple Guideline 4.2 requires more than a repackaged website, test the native controls and document the app-specific functionality in App Review notes.

The website URL is https://www.rememberpills.com
